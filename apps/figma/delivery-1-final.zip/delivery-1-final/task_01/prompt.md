**Difficulty:** Easy

## Prompt

Use the Frame tool from the toolbar and select the MacBook Air preset (1280x832) from the right-panel preset list. Inside the frame, build a simple house: draw a rectangle for the body, add a triangle roof on top spanning the body width with a small overhang on each side, add a front door rectangle on the body, and include 2 small round windows (ellipses) on either side of the door. Apply a different fill color to the body, roof, door, and windows.

