"""Task 03 — Radial flower with petals (end-state only)."""

from verifier.types import Task
from verifier.rubrics.fundamentals import FundamentalsRubric
from verifier.rubrics.alignment import AlignmentRubric
from verifier.rubrics.color import ColorRubric
from verifier.rubrics.structure import StructureRubric
from verifier.rubrics.efficiency import EfficiencyRubric

from verifier.checks.shape_checks import ShapeCount
from verifier.checks.geometry_checks import (
    RadialDistributionExcludeCentral,
    LayersSameDimensionsExcludeCentral,
    LayersTouchCentralLayer,
    LayersElongatedExcludeCentral,
    LayersSmallerThanCentralLayer,
    CentralLayerIsCircular,
)
from verifier.checks.fill_checks import (
    DistinctTypedSolidColorsExcludeCentral,
    CentermostLayerHasColor,
)
from verifier.checks.structure_checks import (
    LayerInsideFrame,
    ChildCount,
    LayerTotalCount,
    NoUnexpectedLayerTypes,
)


task = Task(
    id="task_03_glowing_orb",
    description="1 yellow center circle + 8 elliptical petals (same size, smaller than center, elongated, tip touching circle).",
    rubrics=[
        FundamentalsRubric([
            ShapeCount("ellipse", equals=9),
        ], weight=0.25, critical=[0]),

        AlignmentRubric([
            RadialDistributionExcludeCentral(
                layer_type="ellipse",
                n=8,
                tolerance_deg=15.0,
                radius_tolerance_frac=0.35,
            ),                                                                              # 0 8 petals at equal angles
            LayersSameDimensionsExcludeCentral(layer_type="ellipse", tolerance=6.0),         # 1 petals uniform
            LayersTouchCentralLayer(layer_type="ellipse", tolerance=18.0),                   # 2 each petal touches circle
            CentralLayerIsCircular(layer_type="ellipse", tolerance=4.0),                     # 3 center is a true circle
            LayersElongatedExcludeCentral(layer_type="ellipse", min_ratio=1.5),              # 4 petals elongated
            LayersSmallerThanCentralLayer(layer_type="ellipse", max_ratio=0.95),             # 5 petals smaller than circle
        ], weight=0.25, critical=[0, 1, 2, 3, 4, 5]),

        ColorRubric([
            CentermostLayerHasColor(
                layer_type="ellipse",
                expected_rgb={"r": 1.0, "g": 0.9, "b": 0.2},
                tolerance=0.28,
            ),
            DistinctTypedSolidColorsExcludeCentral(layer_type="ellipse", minimum=8, tolerance=0.12),
        ], weight=0.25, critical=[0, 1]),

        StructureRubric([
            LayerInsideFrame("ellipse"),
            ChildCount("frame", equals=9),
            LayerTotalCount(equals=10),
            NoUnexpectedLayerTypes(allowed_types=["ellipse"]),
        ], weight=0.25, critical=[0, 1, 2, 3]),
    ],
    efficiency=EfficiencyRubric(target_turns=1, lambda_=0.0),
)
